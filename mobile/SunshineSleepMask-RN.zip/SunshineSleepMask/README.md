# Sunshine Sleep Mask — React Native (iOS)

Converted from the Figma Make React web app to React Native using Expo.

## Project Structure

```
App.tsx                         ← Root: NavigationContainer + Stack navigator
src/
  theme.ts                      ← Colors, spacing, font sizes (replaces Tailwind)
  components/
    StarryBackground.tsx        ← Animated twinkling stars (replaces Framer Motion)
  navigation/
    MainLayout.tsx              ← Bottom tab navigator (replaces react-router Outlet)
  screens/
    WelcomeScreen.tsx           ← Animated splash screen (Animated API)
    HomePage.tsx                ← Device status, mask image, settings summary
    AlarmPage.tsx               ← Alarm list with LED sunrise settings
    AmbientSoundPage.tsx        ← Sound picker with tabs + sliders
    SleepDataPage.tsx           ← Sleep charts built with inline SVG
```

## Setup

### 1. Install dependencies

```bash
npm install
```

### 2. Start with Expo Go (quickest)

```bash
npx expo start
```
Scan the QR code with the Expo Go app on your iPhone.

### 3. Run on iOS Simulator (requires Xcode)

```bash
npx expo run:ios
```

## Key Conversion Decisions

| Web (Figma Make)             | React Native                              |
|------------------------------|-------------------------------------------|
| `react-router`               | `@react-navigation/native`               |
| `<div>`, `<span>`            | `<View>`, `<Text>`                        |
| Tailwind CSS classes         | `StyleSheet.create()` via `src/theme.ts` |
| `framer-motion` animations   | `Animated` API                            |
| `recharts` (SVG charts)      | Inline `react-native-svg` charts         |
| `shadcn/ui` components       | Native RN components (Switch, Modal etc) |
| `<input type="time">`        | Text display + modal time picker          |
| CSS `backdrop-blur`          | Semi-transparent View overlay             |
| `lucide-react` icons         | Inline `react-native-svg` icons          |

## Notes

- **SleepMask3D**: The original used a Three.js/3D canvas component. In the RN version
  it's replaced with a static `Image` from Unsplash. For a true 3D model, add
  `expo-gl` + `expo-three` and load a `.glb` asset.

- **Time picker on AlarmPage**: The web used `<input type="time">`. On iOS, you can
  upgrade this to `@react-native-community/datetimepicker` for a native wheel picker.

- **Bluetooth**: Add `react-native-ble-plx` for real BLE device connectivity.

- **Safe area**: `react-native-safe-area-context` handles the iPhone notch/home bar
  so the tab bar sits correctly above the home indicator.

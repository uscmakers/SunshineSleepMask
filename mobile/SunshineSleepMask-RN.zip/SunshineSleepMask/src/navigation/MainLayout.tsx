import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StarryBackground } from '../components/StarryBackground';
import { HomePage } from '../screens/HomePage';
import { AlarmPage } from '../screens/AlarmPage';
import { AmbientSoundPage } from '../screens/AmbientSoundPage';
import { SleepDataPage } from '../screens/SleepDataPage';
import { colors, fontSizes, spacing } from '../theme';

// Simple SVG-free icon components (replace with react-native-vector-icons if preferred)
import Svg, { Path, Polyline, Line, Circle, Rect } from 'react-native-svg';

function HomeIcon({ color }: { color: string }) {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <Polyline points="9 22 9 12 15 12 15 22" />
    </Svg>
  );
}

function AlarmIcon({ color }: { color: string }) {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Circle cx="12" cy="13" r="8" />
      <Path d="M12 9v4l2 2" />
      <Path d="M5 3L2 6" />
      <Path d="M22 6l-3-3" />
    </Svg>
  );
}

function MusicIcon({ color }: { color: string }) {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M9 18V5l12-2v13" />
      <Circle cx="6" cy="18" r="3" />
      <Circle cx="18" cy="16" r="3" />
    </Svg>
  );
}

function ChartIcon({ color }: { color: string }) {
  return (
    <Svg width={24} height={24} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Line x1="18" y1="20" x2="18" y2="10" />
      <Line x1="12" y1="20" x2="12" y2="4" />
      <Line x1="6" y1="20" x2="6" y2="14" />
    </Svg>
  );
}

export type MainTabParamList = {
  Home: undefined;
  Alarm: undefined;
  Sounds: undefined;
  Data: undefined;
};

const Tab = createBottomTabNavigator<MainTabParamList>();

export function MainLayout() {
  const insets = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <StarryBackground />
      <Tab.Navigator
        screenOptions={({ route }) => ({
          headerShown: false,
          tabBarStyle: {
            ...styles.tabBar,
            paddingBottom: insets.bottom || spacing.sm,
            height: 64 + (insets.bottom || 0),
          },
          tabBarActiveTintColor: colors.teal400,
          tabBarInactiveTintColor: colors.neutral500,
          tabBarLabelStyle: styles.tabLabel,
          tabBarBackground: () => <View style={styles.tabBarBackground} />,
          tabBarIcon: ({ color }) => {
            if (route.name === 'Home') return <HomeIcon color={color} />;
            if (route.name === 'Alarm') return <AlarmIcon color={color} />;
            if (route.name === 'Sounds') return <MusicIcon color={color} />;
            if (route.name === 'Data') return <ChartIcon color={color} />;
            return null;
          },
        })}
      >
        <Tab.Screen name="Home" component={HomePage} />
        <Tab.Screen name="Alarm" component={AlarmPage} />
        <Tab.Screen name="Sounds" component={AmbientSoundPage} />
        <Tab.Screen name="Data" component={SleepDataPage} />
      </Tab.Navigator>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.neutral950,
  },
  tabBar: {
    position: 'absolute',
    borderTopColor: colors.neutral800,
    borderTopWidth: 1,
    backgroundColor: 'transparent',
    elevation: 0,
  },
  tabBarBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(23, 23, 23, 0.85)',
  },
  tabLabel: {
    fontSize: fontSizes.xs,
    marginBottom: 2,
  },
});

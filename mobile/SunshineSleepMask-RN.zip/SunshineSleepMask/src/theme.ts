// Central theme file replacing Tailwind CSS classes
export const colors = {
  black: '#000000',
  white: '#FFFFFF',

  // Neutral palette
  neutral950: '#0a0a0a',
  neutral900: '#171717',
  neutral800: '#262626',
  neutral700: '#404040',
  neutral600: '#525252',
  neutral500: '#737373',
  neutral400: '#a3a3a3',
  neutral300: '#d4d4d4',

  // Teal palette
  teal300: '#5eead4',
  teal400: '#2dd4bf',
  teal500: '#14b8a6',
  teal600: '#0d9488',
  teal700: '#0f766e',

  // Teal with opacity (approximate)
  teal500_10: 'rgba(20, 184, 166, 0.1)',
  teal500_20: 'rgba(20, 184, 166, 0.2)',
  teal500_30: 'rgba(20, 184, 166, 0.3)',

  // Transparent
  transparent: 'transparent',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 12,
  base: 16,
  lg: 20,
  xl: 24,
  '2xl': 32,
  '3xl': 40,
  '4xl': 48,
};

export const fontSizes = {
  xs: 10,
  sm: 12,
  base: 14,
  md: 16,
  lg: 18,
  xl: 20,
  '2xl': 24,
  '3xl': 30,
  '4xl': 36,
  '5xl': 48,
};

export const borderRadius = {
  sm: 6,
  md: 8,
  lg: 12,
  xl: 16,
  full: 9999,
};

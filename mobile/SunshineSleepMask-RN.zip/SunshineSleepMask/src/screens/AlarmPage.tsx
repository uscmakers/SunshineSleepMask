import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Switch,
  Modal,
  FlatList,
} from 'react-native';
import Svg, { Circle, Path, Line, Polyline, Rect } from 'react-native-svg';
import { colors, fontSizes, spacing, borderRadius } from '../theme';

// ── Icons ──────────────────────────────────────────────────────────────────────

function ClockIcon({ size = 32, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Circle cx="12" cy="12" r="10" />
      <Polyline points="12 6 12 12 16 14" />
    </Svg>
  );
}

function SunriseIcon({ size = 16, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M17 18a5 5 0 0 0-10 0" />
      <Line x1="12" y1="2" x2="12" y2="9" />
      <Line x1="4.22" y1="10.22" x2="5.64" y2="11.64" />
      <Line x1="1" y1="18" x2="3" y2="18" />
      <Line x1="21" y1="18" x2="23" y2="18" />
      <Line x1="18.36" y1="11.64" x2="19.78" y2="10.22" />
      <Line x1="23" y1="22" x2="1" y2="22" />
      <Polyline points="8 6 12 2 16 6" />
    </Svg>
  );
}

function SunIcon({ size = 16, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Circle cx="12" cy="12" r="5" />
      <Line x1="12" y1="1" x2="12" y2="3" />
      <Line x1="12" y1="21" x2="12" y2="23" />
      <Line x1="4.22" y1="4.22" x2="5.64" y2="5.64" />
      <Line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
      <Line x1="1" y1="12" x2="3" y2="12" />
      <Line x1="21" y1="12" x2="23" y2="12" />
      <Line x1="4.22" y1="19.78" x2="5.64" y2="18.36" />
      <Line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
    </Svg>
  );
}

function TrashIcon({ size = 20, color = colors.neutral500 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polyline points="3 6 5 6 21 6" />
      <Path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6" />
      <Path d="M10 11v6" />
      <Path d="M14 11v6" />
      <Path d="M9 6V4h6v2" />
    </Svg>
  );
}

function PlusIcon({ size = 20, color = colors.neutral400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Line x1="12" y1="5" x2="12" y2="19" />
      <Line x1="5" y1="12" x2="19" y2="12" />
    </Svg>
  );
}

// ── Types ──────────────────────────────────────────────────────────────────────

interface Alarm {
  id: string;
  hour: number;
  minute: number;
  enabled: boolean;
  days: string[];
  label: string;
}

type SunriseType = 'gentle' | 'natural' | 'energize';
const SNOOZE_OPTIONS = [5, 9, 10, 15, 20];
const ALL_DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

const SUNRISE_PATTERNS: { key: SunriseType; label: string; desc: string; Icon: typeof SunriseIcon }[] = [
  { key: 'gentle', label: 'Gentle Sunrise', desc: 'Gradual warm light increase', Icon: SunriseIcon },
  { key: 'natural', label: 'Natural Dawn', desc: 'Mimics actual sunrise colors', Icon: SunIcon },
  { key: 'energize', label: 'Energizing Wake', desc: 'Bright light for quick wake-up', Icon: SunriseIcon },
];

// ── Slider (simple native implementation) ─────────────────────────────────────

function SimpleSlider({
  value,
  min,
  max,
  step,
  onChange,
}: {
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  const steps = (max - min) / step;
  const currentStep = (value - min) / step;

  return (
    <View style={sliderStyles.container}>
      <View style={sliderStyles.track}>
        <View style={[sliderStyles.fill, { width: `${(currentStep / steps) * 100}%` }]} />
      </View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={sliderStyles.stepsScroll}>
        <View style={sliderStyles.stepsRow}>
          {Array.from({ length: steps + 1 }, (_, i) => (
            <TouchableOpacity
              key={i}
              style={[
                sliderStyles.stepDot,
                i === currentStep && sliderStyles.stepDotActive,
              ]}
              onPress={() => onChange(min + i * step)}
            />
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const sliderStyles = StyleSheet.create({
  container: { paddingVertical: spacing.sm },
  track: {
    height: 4,
    backgroundColor: colors.neutral700,
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: spacing.sm,
  },
  fill: { height: '100%', backgroundColor: colors.teal500 },
  stepsScroll: {},
  stepsRow: { flexDirection: 'row', gap: 0 },
  stepDot: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: colors.neutral700,
    borderWidth: 2,
    borderColor: colors.neutral600,
  },
  stepDotActive: {
    backgroundColor: colors.teal500,
    borderColor: colors.teal400,
  },
});

// ── Main Component ─────────────────────────────────────────────────────────────

export function AlarmPage() {
  const [alarms, setAlarms] = useState<Alarm[]>([
    { id: '1', hour: 7, minute: 0, enabled: true, days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'], label: 'Weekday Alarm' },
    { id: '2', hour: 9, minute: 0, enabled: false, days: ['Sat', 'Sun'], label: 'Weekend Alarm' },
  ]);
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [snoozeTime, setSnoozeTime] = useState(9);
  const [sunriseType, setSunriseType] = useState<SunriseType>('gentle');
  const [sunriseDuration, setSunriseDuration] = useState(20);
  const [snoozePickerVisible, setSnoozePickerVisible] = useState(false);

  const formatTime = (h: number, m: number) =>
    `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;

  const toggleAlarm = (id: string) =>
    setAlarms(prev => prev.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));

  const deleteAlarm = (id: string) => {
    setAlarms(prev => prev.filter(a => a.id !== id));
    if (expandedId === id) setExpandedId(null);
  };

  const addAlarm = () => {
    setAlarms(prev => [
      ...prev,
      { id: Date.now().toString(), hour: 8, minute: 0, enabled: false, days: [], label: 'New Alarm' },
    ]);
  };

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerIconWrap}>
          <ClockIcon size={32} />
        </View>
        <Text style={styles.headerTitle}>Alarms</Text>
        <Text style={styles.headerSubtitle}>Manage your wake-up alarms</Text>
      </View>

      {/* Alarm list */}
      <View style={styles.gap3}>
        {alarms.map(alarm => (
          <View
            key={alarm.id}
            style={[styles.card, alarm.enabled && styles.cardActive]}
          >
            {/* Alarm header row */}
            <View style={styles.alarmHeader}>
              <View style={styles.timeRow}>
                <Text style={styles.timeText}>{formatTime(alarm.hour, alarm.minute)}</Text>
                <Switch
                  value={alarm.enabled}
                  onValueChange={() => toggleAlarm(alarm.id)}
                  trackColor={{ false: colors.neutral700, true: colors.teal600 }}
                  thumbColor={alarm.enabled ? colors.teal400 : colors.neutral400}
                />
              </View>
              <TouchableOpacity onPress={() => deleteAlarm(alarm.id)} style={styles.trashBtn}>
                <TrashIcon />
              </TouchableOpacity>
            </View>

            {/* Days & expand */}
            <View style={styles.daysRow}>
              <View>
                <Text style={styles.alarmLabel}>{alarm.label}</Text>
                <View style={styles.daysWrap}>
                  {alarm.days.length > 0
                    ? alarm.days.map(d => (
                        <View key={d} style={styles.dayBadge}>
                          <Text style={styles.dayBadgeText}>{d}</Text>
                        </View>
                      ))
                    : <Text style={styles.oneTime}>One time</Text>}
                </View>
              </View>
              <TouchableOpacity
                style={styles.ledBtn}
                onPress={() => setExpandedId(expandedId === alarm.id ? null : alarm.id)}
              >
                <SunriseIcon size={14} />
                <Text style={styles.ledBtnText}>LED Settings</Text>
                <Text style={styles.ledChevron}>{expandedId === alarm.id ? '▲' : '▽'}</Text>
              </TouchableOpacity>
            </View>

            {/* Expanded LED settings */}
            {expandedId === alarm.id && (
              <View style={styles.expanded}>
                {/* Sunrise patterns */}
                <Text style={styles.sectionLabel}>Sunrise Pattern</Text>
                {SUNRISE_PATTERNS.map(({ key, label, desc, Icon }) => (
                  <TouchableOpacity
                    key={key}
                    style={[styles.patternBtn, sunriseType === key && styles.patternBtnActive]}
                    onPress={() => setSunriseType(key)}
                  >
                    <View style={styles.patternIcon}>
                      <Icon size={16} />
                    </View>
                    <View>
                      <Text style={styles.patternLabel}>{label}</Text>
                      <Text style={styles.patternDesc}>{desc}</Text>
                    </View>
                  </TouchableOpacity>
                ))}

                {/* Duration slider */}
                <Text style={styles.sectionLabel}>
                  Sunrise Duration: {sunriseDuration} minutes
                </Text>
                <SimpleSlider
                  value={sunriseDuration}
                  min={5}
                  max={45}
                  step={5}
                  onChange={setSunriseDuration}
                />
                <View style={styles.sliderLabels}>
                  <Text style={styles.sliderLabelText}>5 min</Text>
                  <Text style={styles.sliderLabelText}>45 min</Text>
                </View>

                {/* Snooze picker */}
                <Text style={styles.sectionLabel}>Snooze Duration: {snoozeTime} minutes</Text>
                <TouchableOpacity
                  style={styles.snoozeTrigger}
                  onPress={() => setSnoozePickerVisible(true)}
                >
                  <Text style={styles.snoozeValue}>{snoozeTime} minutes</Text>
                  <Text style={styles.snoozeChevron}>▽</Text>
                </TouchableOpacity>

                {/* Preview */}
                <View style={styles.previewBox}>
                  <Text style={styles.previewText}>
                    Your alarm will start at {formatTime(alarm.hour, alarm.minute)} with a{' '}
                    {sunriseDuration}-minute {sunriseType} sunrise simulation.
                  </Text>
                  <TouchableOpacity style={styles.testBtn}>
                    <Text style={styles.testBtnText}>Test Simulation</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </View>
        ))}
      </View>

      {/* Add alarm */}
      <TouchableOpacity style={styles.addBtn} onPress={addAlarm}>
        <PlusIcon />
        <Text style={styles.addBtnText}>Add New Alarm</Text>
      </TouchableOpacity>

      {/* Tip */}
      <View style={styles.tipCard}>
        <Text style={styles.tipText}>
          💡 Tap "LED Settings" on any alarm to customize the sunrise simulation
        </Text>
      </View>

      {/* Snooze Modal */}
      <Modal
        visible={snoozePickerVisible}
        transparent
        animationType="slide"
        onRequestClose={() => setSnoozePickerVisible(false)}
      >
        <TouchableOpacity
          style={styles.modalOverlay}
          activeOpacity={1}
          onPress={() => setSnoozePickerVisible(false)}
        >
          <View style={styles.modalSheet}>
            <Text style={styles.modalTitle}>Snooze Duration</Text>
            {SNOOZE_OPTIONS.map(opt => (
              <TouchableOpacity
                key={opt}
                style={[styles.modalOption, snoozeTime === opt && styles.modalOptionActive]}
                onPress={() => { setSnoozeTime(opt); setSnoozePickerVisible(false); }}
              >
                <Text style={[styles.modalOptionText, snoozeTime === opt && styles.modalOptionTextActive]}>
                  {opt} minutes
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  container: { padding: spacing.xl, paddingBottom: 80, gap: spacing.xl },
  gap3: { gap: spacing.md },

  // Header
  header: { alignItems: 'center', paddingTop: spacing.base },
  headerIconWrap: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: colors.teal500_10,
    borderWidth: 1, borderColor: colors.teal500_20,
    alignItems: 'center', justifyContent: 'center',
    marginBottom: spacing.md,
  },
  headerTitle: { fontSize: fontSizes['3xl'], color: colors.white, fontWeight: '300', marginBottom: spacing.xs },
  headerSubtitle: { color: colors.neutral400, fontSize: fontSizes.base },

  // Card
  card: {
    backgroundColor: colors.neutral900,
    borderWidth: 1, borderColor: colors.neutral800,
    borderRadius: borderRadius.lg,
    padding: spacing.base,
  },
  cardActive: { borderColor: colors.teal500_30 },

  // Alarm header
  alarmHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: spacing.sm },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.base },
  timeText: { fontSize: 36, fontWeight: '300', color: colors.white },
  trashBtn: { padding: spacing.sm },

  // Days
  daysRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  alarmLabel: { color: colors.neutral400, fontSize: fontSizes.sm, marginBottom: spacing.xs },
  daysWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.xs },
  dayBadge: { backgroundColor: colors.teal500_20, paddingHorizontal: spacing.sm, paddingVertical: 2, borderRadius: borderRadius.sm },
  dayBadgeText: { color: colors.teal400, fontSize: fontSizes.xs },
  oneTime: { color: colors.neutral500, fontSize: fontSizes.xs },
  ledBtn: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs },
  ledBtnText: { color: colors.teal400, fontSize: fontSizes.sm },
  ledChevron: { color: colors.teal400, fontSize: fontSizes.xs },

  // Expanded
  expanded: {
    marginTop: spacing.base,
    paddingTop: spacing.base,
    borderTopWidth: 1,
    borderTopColor: colors.neutral800,
    gap: spacing.base,
  },
  sectionLabel: { color: colors.neutral400, fontSize: fontSizes.sm },
  patternBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.md,
    padding: spacing.md,
    borderRadius: borderRadius.md,
    borderWidth: 1,
    borderColor: colors.neutral700,
    backgroundColor: colors.neutral800,
  },
  patternBtnActive: { borderColor: colors.teal500, backgroundColor: colors.teal500_10 },
  patternIcon: { padding: spacing.sm, borderRadius: borderRadius.full, backgroundColor: colors.teal500_10 },
  patternLabel: { color: colors.white, fontSize: fontSizes.sm, fontWeight: '600' },
  patternDesc: { color: colors.neutral400, fontSize: fontSizes.xs },
  sliderLabels: { flexDirection: 'row', justifyContent: 'space-between' },
  sliderLabelText: { color: colors.neutral500, fontSize: fontSizes.xs },

  // Snooze
  snoozeTrigger: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: colors.neutral800, borderWidth: 1, borderColor: colors.neutral700,
    borderRadius: borderRadius.md, padding: spacing.md,
  },
  snoozeValue: { color: colors.white, fontSize: fontSizes.base },
  snoozeChevron: { color: colors.neutral400 },

  // Preview
  previewBox: { backgroundColor: colors.teal500_10, borderWidth: 1, borderColor: colors.teal500_20, borderRadius: borderRadius.md, padding: spacing.base, gap: spacing.md },
  previewText: { color: colors.neutral300, fontSize: fontSizes.sm },
  testBtn: { backgroundColor: colors.teal500, borderRadius: borderRadius.md, paddingVertical: spacing.sm, alignItems: 'center' },
  testBtnText: { color: colors.white, fontWeight: '600', fontSize: fontSizes.sm },

  // Add alarm
  addBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: spacing.sm,
    borderWidth: 2, borderStyle: 'dashed', borderColor: colors.neutral700,
    borderRadius: borderRadius.md, padding: spacing.base,
  },
  addBtnText: { color: colors.neutral400, fontSize: fontSizes.base },

  // Tip
  tipCard: {
    backgroundColor: colors.teal500_10, borderWidth: 1, borderColor: colors.teal500_20,
    borderRadius: borderRadius.md, padding: spacing.base,
  },
  tipText: { color: colors.neutral300, fontSize: fontSizes.sm, textAlign: 'center' },

  // Modal
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'flex-end' },
  modalSheet: {
    backgroundColor: colors.neutral900, borderTopLeftRadius: borderRadius.xl, borderTopRightRadius: borderRadius.xl,
    padding: spacing.xl, gap: spacing.sm,
  },
  modalTitle: { color: colors.white, fontSize: fontSizes.lg, fontWeight: '600', marginBottom: spacing.sm },
  modalOption: { padding: spacing.base, borderRadius: borderRadius.md, backgroundColor: colors.neutral800 },
  modalOptionActive: { backgroundColor: colors.teal500_10, borderWidth: 1, borderColor: colors.teal500_30 },
  modalOptionText: { color: colors.neutral300, fontSize: fontSizes.base },
  modalOptionTextActive: { color: colors.teal400, fontWeight: '600' },
});

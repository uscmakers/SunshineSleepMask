import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import Svg, { Path, Circle, Line, Polygon } from 'react-native-svg';
import { colors, fontSizes, spacing, borderRadius } from '../theme';

// ── Icons ──────────────────────────────────────────────────────────────────────

function Music2Icon({ size = 32, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M9 18V5l12-2v13" />
      <Circle cx="6" cy="18" r="3" />
      <Circle cx="18" cy="16" r="3" />
    </Svg>
  );
}

function Volume2Icon({ size = 20, color = colors.neutral400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5" />
      <Path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
      <Path d="M15.54 8.46a5 5 0 0 1 0 7.07" />
    </Svg>
  );
}

function PlayIcon({ size = 20, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill={color} stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polygon points="5 3 19 12 5 21 5 3" />
    </Svg>
  );
}

function PauseIcon({ size = 20, color = colors.white }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Line x1="6" y1="4" x2="6" y2="20" />
      <Line x1="18" y1="4" x2="18" y2="20" />
    </Svg>
  );
}

// ── Reusable Slider ────────────────────────────────────────────────────────────

function SliderRow({
  label,
  value,
  displayValue,
  min,
  max,
  step,
  onChange,
}: {
  label: string;
  value: number;
  displayValue: string;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}) {
  const steps = (max - min) / step;
  const pct = ((value - min) / (max - min)) * 100;

  return (
    <View style={slStyles.container}>
      <View style={slStyles.labelRow}>
        <Text style={slStyles.label}>{label}</Text>
        <Text style={slStyles.value}>{displayValue}</Text>
      </View>
      <View style={slStyles.track}>
        <View style={[slStyles.fill, { width: `${pct}%` }]} />
      </View>
      <View style={slStyles.tapsRow}>
        {Array.from({ length: steps + 1 }, (_, i) => {
          const tapVal = min + i * step;
          return (
            <TouchableOpacity
              key={i}
              style={[slStyles.tap, tapVal === value && slStyles.tapActive]}
              onPress={() => onChange(tapVal)}
            />
          );
        })}
      </View>
    </View>
  );
}

const slStyles = StyleSheet.create({
  container: { gap: spacing.sm },
  labelRow: { flexDirection: 'row', justifyContent: 'space-between' },
  label: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base },
  value: { color: colors.neutral400, fontSize: fontSizes.sm },
  track: {
    height: 4, backgroundColor: colors.neutral700,
    borderRadius: 2, overflow: 'hidden',
  },
  fill: { height: '100%', backgroundColor: colors.teal500 },
  tapsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  tap: { width: 20, height: 20, borderRadius: 10, backgroundColor: colors.neutral700 },
  tapActive: { backgroundColor: colors.teal500 },
});

// ── Data ───────────────────────────────────────────────────────────────────────

const AMBIENT_SOUNDS = [
  { id: 1, name: 'Rain', icon: '🌧️', duration: '60 min' },
  { id: 2, name: 'Ocean Waves', icon: '🌊', duration: '60 min' },
  { id: 3, name: 'Forest', icon: '🌲', duration: '45 min' },
  { id: 4, name: 'White Noise', icon: '📻', duration: '∞' },
  { id: 5, name: 'Thunderstorm', icon: '⛈️', duration: '60 min' },
  { id: 6, name: 'Campfire', icon: '🔥', duration: '45 min' },
  { id: 7, name: 'Wind', icon: '💨', duration: '60 min' },
  { id: 8, name: 'Birds', icon: '🐦', duration: '30 min' },
];

const SPOTIFY_PLAYLISTS = [
  { id: 1, name: 'Sleep Sounds', tracks: 50 },
  { id: 2, name: 'Peaceful Piano', tracks: 100 },
  { id: 3, name: 'Ambient Relaxation', tracks: 75 },
  { id: 4, name: 'Deep Sleep', tracks: 60 },
  { id: 5, name: 'Nature Sounds', tracks: 45 },
  { id: 6, name: 'Meditation Music', tracks: 80 },
];

// ── Main Component ─────────────────────────────────────────────────────────────

export function AmbientSoundPage() {
  const [playingSound, setPlayingSound] = useState<number | null>(null);
  const [volume, setVolume] = useState(70);
  const [timer, setTimer] = useState(30);
  const [activeTab, setActiveTab] = useState<'ambient' | 'spotify'>('ambient');

  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerIconWrap}>
          <Music2Icon size={32} />
        </View>
        <Text style={styles.headerTitle}>Ambient Sounds</Text>
        <Text style={styles.headerSubtitle}>Relax and drift off to sleep</Text>
      </View>

      {/* Volume & Timer */}
      <View style={styles.card}>
        <SliderRow
          label="Volume"
          value={volume}
          displayValue={`${volume}%`}
          min={0}
          max={100}
          step={10}
          onChange={setVolume}
        />
        <View style={styles.divider} />
        <SliderRow
          label="Sleep Timer"
          value={timer}
          displayValue={`${timer} min`}
          min={5}
          max={120}
          step={5}
          onChange={setTimer}
        />
      </View>

      {/* Tabs */}
      <View style={styles.tabBar}>
        {(['ambient', 'spotify'] as const).map(tab => (
          <TouchableOpacity
            key={tab}
            style={[styles.tab, activeTab === tab && styles.tabActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
              {tab === 'ambient' ? 'Ambient Sounds' : 'Spotify'}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Tab content */}
      {activeTab === 'ambient' ? (
        <View style={styles.gap3}>
          {AMBIENT_SOUNDS.map(sound => (
            <View
              key={sound.id}
              style={[styles.soundCard, playingSound === sound.id && styles.soundCardActive]}
            >
              <View style={styles.soundRow}>
                <Text style={styles.soundEmoji}>{sound.icon}</Text>
                <View style={styles.flex1}>
                  <Text style={styles.soundName}>{sound.name}</Text>
                  <Text style={styles.soundDuration}>{sound.duration}</Text>
                </View>
                <TouchableOpacity
                  style={[styles.playBtn, playingSound === sound.id && styles.playBtnActive]}
                  onPress={() => setPlayingSound(playingSound === sound.id ? null : sound.id)}
                >
                  {playingSound === sound.id
                    ? <PauseIcon size={20} color={colors.white} />
                    : <PlayIcon size={20} color={colors.neutral400} />}
                </TouchableOpacity>
              </View>
            </View>
          ))}
        </View>
      ) : (
        <View style={styles.gap3}>
          {/* Connect card */}
          <View style={styles.spotifyConnectCard}>
            <View style={styles.spotifyHeader}>
              <Music2Icon size={24} />
              <Text style={styles.spotifyTitle}>Spotify Integration</Text>
            </View>
            <Text style={styles.spotifyDesc}>
              Connect your Spotify account to access your personal playlists
            </Text>
            <TouchableOpacity style={styles.connectBtn}>
              <Text style={styles.connectBtnText}>Connect Spotify</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.recLabel}>Recommended Playlists</Text>

          {SPOTIFY_PLAYLISTS.map(pl => (
            <TouchableOpacity key={pl.id} style={styles.playlistCard} activeOpacity={0.7}>
              <View style={styles.playlistThumb}>
                <Music2Icon size={32} color={colors.neutral600} />
              </View>
              <View style={styles.flex1}>
                <Text style={styles.playlistName}>{pl.name}</Text>
                <Text style={styles.playlistTracks}>{pl.tracks} tracks</Text>
              </View>
              <TouchableOpacity style={styles.playlistPlayBtn}>
                <PlayIcon size={20} color={colors.neutral400} />
              </TouchableOpacity>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  container: { padding: spacing.xl, paddingBottom: 80, gap: spacing.xl },

  // Header
  header: { alignItems: 'center', paddingTop: spacing.base },
  headerIconWrap: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: colors.teal500_10,
    borderWidth: 1, borderColor: colors.teal500_20,
    alignItems: 'center', justifyContent: 'center', marginBottom: spacing.md,
  },
  headerTitle: { fontSize: fontSizes['3xl'], color: colors.white, fontWeight: '300', marginBottom: spacing.xs },
  headerSubtitle: { color: colors.neutral400, fontSize: fontSizes.base },

  // Card
  card: {
    backgroundColor: colors.neutral900, borderWidth: 1, borderColor: colors.neutral800,
    borderRadius: borderRadius.lg, padding: spacing.xl, gap: spacing.xl,
  },
  divider: { height: 1, backgroundColor: colors.neutral800 },

  // Tabs
  tabBar: {
    flexDirection: 'row', backgroundColor: colors.neutral900,
    borderWidth: 1, borderColor: colors.neutral800, borderRadius: borderRadius.md, overflow: 'hidden',
  },
  tab: { flex: 1, paddingVertical: spacing.md, alignItems: 'center' },
  tabActive: { backgroundColor: colors.teal500_10 },
  tabText: { color: colors.neutral500, fontSize: fontSizes.base },
  tabTextActive: { color: colors.teal400, fontWeight: '600' },
  gap3: { gap: spacing.md },
  flex1: { flex: 1 },

  // Sound cards
  soundCard: {
    backgroundColor: colors.neutral900, borderWidth: 1, borderColor: colors.neutral800,
    borderRadius: borderRadius.md, padding: spacing.base,
  },
  soundCardActive: { borderColor: colors.teal500, borderWidth: 2 },
  soundRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  soundEmoji: { fontSize: 32 },
  soundName: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base },
  soundDuration: { color: colors.neutral400, fontSize: fontSizes.sm, marginTop: 2 },
  playBtn: {
    width: 44, height: 44, borderRadius: 22,
    backgroundColor: colors.neutral800, alignItems: 'center', justifyContent: 'center',
  },
  playBtnActive: { backgroundColor: colors.teal500 },

  // Spotify
  spotifyConnectCard: {
    backgroundColor: colors.teal500_10, borderWidth: 1, borderColor: colors.teal500_20,
    borderRadius: borderRadius.md, padding: spacing.base, gap: spacing.md,
  },
  spotifyHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  spotifyTitle: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base },
  spotifyDesc: { color: colors.neutral300, fontSize: fontSizes.sm },
  connectBtn: {
    backgroundColor: colors.teal500, borderRadius: borderRadius.md,
    paddingVertical: spacing.sm, alignItems: 'center',
  },
  connectBtnText: { color: colors.white, fontWeight: '600' },
  recLabel: { color: colors.neutral400, fontSize: fontSizes.sm },
  playlistCard: {
    flexDirection: 'row', alignItems: 'center', gap: spacing.base,
    backgroundColor: colors.neutral900, borderWidth: 1, borderColor: colors.neutral800,
    borderRadius: borderRadius.md, padding: spacing.base,
  },
  playlistThumb: {
    width: 64, height: 64, backgroundColor: colors.neutral800,
    borderRadius: borderRadius.md, alignItems: 'center', justifyContent: 'center',
  },
  playlistName: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base },
  playlistTracks: { color: colors.neutral400, fontSize: fontSizes.sm, marginTop: 2 },
  playlistPlayBtn: {
    width: 36, height: 36, borderRadius: 18,
    backgroundColor: colors.neutral800, alignItems: 'center', justifyContent: 'center',
  },
});

import React from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Dimensions,
} from 'react-native';
import Svg, { Path, Polyline, Line, Circle, Rect, G, Text as SvgText } from 'react-native-svg';
import { colors, fontSizes, spacing, borderRadius } from '../theme';

const { width: SCREEN_W } = Dimensions.get('window');
const CHART_W = SCREEN_W - spacing.xl * 2 - spacing.xl * 2; // full width minus card padding
const CHART_H = 180;

// ── Icons ──────────────────────────────────────────────────────────────────────

function ActivityIcon({ size = 32, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </Svg>
  );
}

function ClockIcon({ size = 20, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Circle cx="12" cy="12" r="10" />
      <Polyline points="12 6 12 12 16 14" />
    </Svg>
  );
}

function TrendUpIcon({ size = 20, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polyline points="23 6 13.5 15.5 8.5 10.5 1 18" />
      <Polyline points="17 6 23 6 23 12" />
    </Svg>
  );
}

function MoonIcon({ size = 20, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </Svg>
  );
}

// ── Data ───────────────────────────────────────────────────────────────────────

const weeklyData = [
  { day: 'Mon', hours: 7.2, quality: 85, deep: 2.1 },
  { day: 'Tue', hours: 6.8, quality: 78, deep: 1.8 },
  { day: 'Wed', hours: 8.1, quality: 92, deep: 2.4 },
  { day: 'Thu', hours: 7.5, quality: 88, deep: 2.2 },
  { day: 'Fri', hours: 6.5, quality: 75, deep: 1.6 },
  { day: 'Sat', hours: 8.5, quality: 95, deep: 2.8 },
  { day: 'Sun', hours: 7.8, quality: 90, deep: 2.3 },
];

const sleepStages = [
  { time: '22', awake: 0, light: 20, deep: 0, rem: 0 },
  { time: '23', awake: 5, light: 35, deep: 15, rem: 0 },
  { time: '00', awake: 0, light: 25, deep: 35, rem: 10 },
  { time: '01', awake: 0, light: 20, deep: 40, rem: 15 },
  { time: '02', awake: 5, light: 30, deep: 25, rem: 20 },
  { time: '03', awake: 0, light: 35, deep: 15, rem: 25 },
  { time: '04', awake: 0, light: 30, deep: 20, rem: 25 },
  { time: '05', awake: 5, light: 35, deep: 10, rem: 20 },
  { time: '06', awake: 10, light: 40, deep: 5, rem: 15 },
];

// ── Inline SVG Charts ──────────────────────────────────────────────────────────

function BarChart({ data }: { data: typeof weeklyData }) {
  const maxH = Math.max(...data.map(d => d.hours));
  const barW = CHART_W / data.length;
  const padLeft = 28;
  const padBottom = 24;
  const chartH = CHART_H - padBottom;
  const chartW = CHART_W - padLeft;

  return (
    <Svg width={CHART_W} height={CHART_H}>
      {/* Y-axis labels */}
      {[0, 2, 4, 6, 8].map(v => {
        const y = chartH - (v / maxH) * chartH;
        return (
          <G key={v}>
            <Line x1={padLeft} y1={y} x2={CHART_W} y2={y} stroke={colors.neutral800} strokeWidth={1} />
            <SvgText x={padLeft - 4} y={y + 4} fill={colors.neutral500} fontSize={9} textAnchor="end">{v}</SvgText>
          </G>
        );
      })}
      {/* Bars */}
      {data.map((d, i) => {
        const barH = (d.hours / maxH) * chartH;
        const x = padLeft + i * (chartW / data.length) + (chartW / data.length) * 0.15;
        const w = (chartW / data.length) * 0.7;
        return (
          <G key={d.day}>
            <Rect
              x={x} y={chartH - barH} width={w} height={barH}
              fill={colors.teal500} rx={4}
            />
            <SvgText
              x={x + w / 2} y={CHART_H - 6}
              fill={colors.neutral500} fontSize={10} textAnchor="middle"
            >{d.day}</SvgText>
          </G>
        );
      })}
    </Svg>
  );
}

function LineChart({ data }: { data: typeof weeklyData }) {
  const maxQ = 100;
  const padLeft = 28;
  const padBottom = 24;
  const chartH = CHART_H - padBottom;
  const chartW = CHART_W - padLeft;
  const stepX = chartW / (data.length - 1);

  const pts = data.map((d, i) => ({
    x: padLeft + i * stepX,
    y: chartH - (d.quality / maxQ) * chartH,
  }));

  const pathD = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.y}`).join(' ');

  return (
    <Svg width={CHART_W} height={CHART_H}>
      {[0, 25, 50, 75, 100].map(v => {
        const y = chartH - (v / maxQ) * chartH;
        return (
          <G key={v}>
            <Line x1={padLeft} y1={y} x2={CHART_W} y2={y} stroke={colors.neutral800} strokeWidth={1} />
            <SvgText x={padLeft - 4} y={y + 4} fill={colors.neutral500} fontSize={9} textAnchor="end">{v}</SvgText>
          </G>
        );
      })}
      <Path d={pathD} stroke={colors.teal500} strokeWidth={2.5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => (
        <G key={i}>
          <Circle cx={p.x} cy={p.y} r={4} fill={colors.teal500} />
          <SvgText x={p.x} y={CHART_H - 6} fill={colors.neutral500} fontSize={10} textAnchor="middle">
            {data[i].day}
          </SvgText>
        </G>
      ))}
    </Svg>
  );
}

function SleepStageChart({ data }: { data: typeof sleepStages }) {
  const padLeft = 24;
  const padBottom = 24;
  const chartH = CHART_H - padBottom;
  const chartW = CHART_W - padLeft;
  const stepX = chartW / (data.length - 1);

  const layers = [
    { key: 'deep' as const, color: colors.teal700 },
    { key: 'rem' as const, color: colors.teal500 },
    { key: 'light' as const, color: colors.teal300 },
    { key: 'awake' as const, color: colors.neutral600 },
  ];

  const maxVal = Math.max(...data.map(d => d.awake + d.light + d.deep + d.rem));

  // Build stacked area paths
  const stackedPaths = layers.map((layer, layerIdx) => {
    const belowLayers = layers.slice(layerIdx + 1);
    const pts = data.map((d, i) => {
      const x = padLeft + i * stepX;
      const base = belowLayers.reduce((s, l) => s + d[l.key], 0);
      const top = base + d[layer.key];
      return { x, yTop: chartH - (top / maxVal) * chartH, yBase: chartH - (base / maxVal) * chartH };
    });
    const fwdPath = pts.map((p, i) => `${i === 0 ? 'M' : 'L'}${p.x},${p.yTop}`).join(' ');
    const bwdPath = [...pts].reverse().map((p, i) => `${i === 0 ? 'L' : 'L'}${p.x},${p.yBase}`).join(' ');
    return { color: layer.color, path: `${fwdPath} ${bwdPath} Z` };
  });

  return (
    <Svg width={CHART_W} height={CHART_H}>
      {stackedPaths.map((sp, i) => (
        <Path key={i} d={sp.path} fill={sp.color} opacity={0.85} />
      ))}
      {data.map((d, i) => (
        <SvgText
          key={i}
          x={padLeft + i * stepX}
          y={CHART_H - 6}
          fill={colors.neutral500}
          fontSize={9}
          textAnchor="middle"
        >{d.time}</SvgText>
      ))}
    </Svg>
  );
}

// ── Summary card ──────────────────────────────────────────────────────────────

function StatCard({
  Icon,
  label,
  value,
  change,
  positive,
}: {
  Icon: React.ComponentType<{ size?: number; color?: string }>;
  label: string;
  value: string;
  change: string;
  positive: boolean;
}) {
  return (
    <View style={styles.statCard}>
      <View style={styles.statHeader}>
        <Icon size={20} />
        <Text style={styles.statLabel}>{label}</Text>
      </View>
      <Text style={styles.statValue}>{value}</Text>
      <Text style={[styles.statChange, positive ? styles.statChangePos : styles.statChangeNeu]}>
        {change}
      </Text>
    </View>
  );
}

// ── Main Component ─────────────────────────────────────────────────────────────

export function SleepDataPage() {
  return (
    <ScrollView style={styles.scroll} contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.headerIconWrap}>
          <ActivityIcon size={32} />
        </View>
        <Text style={styles.headerTitle}>Sleep Data</Text>
        <Text style={styles.headerSubtitle}>Insights from your Apple Watch</Text>
      </View>

      {/* Summary grid */}
      <View style={styles.statsGrid}>
        <StatCard Icon={ClockIcon} label="Avg Duration" value="7.5h" change="↑ 12% vs last week" positive />
        <StatCard Icon={TrendUpIcon} label="Avg Quality" value="86%" change="↑ 5% vs last week" positive />
        <StatCard Icon={MoonIcon} label="Deep Sleep" value="2.2h" change="↑ 8% vs last week" positive />
        <StatCard Icon={ActivityIcon} label="REM Sleep" value="1.8h" change="— Same as last week" positive={false} />
      </View>

      {/* Bar chart */}
      <View style={styles.chartCard}>
        <Text style={styles.chartTitle}>Weekly Sleep Duration</Text>
        <BarChart data={weeklyData} />
      </View>

      {/* Line chart */}
      <View style={styles.chartCard}>
        <Text style={styles.chartTitle}>Sleep Quality Trend</Text>
        <LineChart data={weeklyData} />
      </View>

      {/* Area chart */}
      <View style={styles.chartCard}>
        <Text style={styles.chartTitle}>Last Night's Sleep Stages</Text>
        <Text style={styles.chartSubtitle}>March 2, 2026 • 10:00 PM - 6:00 AM</Text>
        <SleepStageChart data={sleepStages} />
        <View style={styles.legend}>
          {[
            { color: colors.teal700, label: 'Deep' },
            { color: colors.teal500, label: 'REM' },
            { color: colors.teal300, label: 'Light' },
            { color: colors.neutral600, label: 'Awake' },
          ].map(({ color, label }) => (
            <View key={label} style={styles.legendItem}>
              <View style={[styles.legendDot, { backgroundColor: color }]} />
              <Text style={styles.legendLabel}>{label}</Text>
            </View>
          ))}
        </View>
      </View>

      {/* Insights */}
      <View style={styles.insightCard}>
        <Text style={styles.insightTitle}>💡 Sleep Insights</Text>
        {[
          'Your sleep quality improved by 5% this week',
          "You're getting consistent deep sleep cycles",
          'Try going to bed 15 minutes earlier for optimal rest',
          'Your weekend sleep is 18% better than weekdays',
        ].map((tip, i) => (
          <Text key={i} style={styles.insightItem}>• {tip}</Text>
        ))}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  container: { padding: spacing.xl, paddingBottom: 80, gap: spacing.xl },

  // Header
  header: { alignItems: 'center', paddingTop: spacing.base },
  headerIconWrap: {
    width: 64, height: 64, borderRadius: 32,
    backgroundColor: colors.teal500_10,
    borderWidth: 1, borderColor: colors.teal500_20,
    alignItems: 'center', justifyContent: 'center', marginBottom: spacing.md,
  },
  headerTitle: { fontSize: fontSizes['3xl'], color: colors.white, fontWeight: '300', marginBottom: spacing.xs },
  headerSubtitle: { color: colors.neutral400, fontSize: fontSizes.base },

  // Stats grid
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: spacing.base },
  statCard: {
    flex: 1, minWidth: '45%',
    backgroundColor: colors.neutral900, borderWidth: 1, borderColor: colors.neutral800,
    borderRadius: borderRadius.md, padding: spacing.base,
  },
  statHeader: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, marginBottom: spacing.sm },
  statLabel: { color: colors.neutral400, fontSize: fontSizes.sm },
  statValue: { color: colors.white, fontSize: fontSizes['3xl'], fontWeight: '300' },
  statChange: { fontSize: fontSizes.sm, marginTop: spacing.xs },
  statChangePos: { color: colors.teal400 },
  statChangeNeu: { color: colors.neutral400 },

  // Charts
  chartCard: {
    backgroundColor: colors.neutral900, borderWidth: 1, borderColor: colors.neutral800,
    borderRadius: borderRadius.lg, padding: spacing.xl,
  },
  chartTitle: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base, marginBottom: spacing.base },
  chartSubtitle: { color: colors.neutral400, fontSize: fontSizes.sm, marginBottom: spacing.base },

  // Legend
  legend: { flexDirection: 'row', gap: spacing.base, marginTop: spacing.base, flexWrap: 'wrap' },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
  legendDot: { width: 12, height: 12, borderRadius: 6 },
  legendLabel: { color: colors.neutral400, fontSize: fontSizes.sm },

  // Insights
  insightCard: {
    backgroundColor: colors.teal500_10, borderWidth: 1, borderColor: colors.teal500_20,
    borderRadius: borderRadius.lg, padding: spacing.xl,
  },
  insightTitle: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base, marginBottom: spacing.md },
  insightItem: { color: colors.neutral300, fontSize: fontSizes.sm, marginBottom: spacing.sm },
});

import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  Image,
  Animated,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { StarryBackground } from '../components/StarryBackground';
import { RootStackParamList } from '../../App';
import { colors, fontSizes, spacing } from '../theme';

type Props = NativeStackScreenProps<RootStackParamList, 'Welcome'>;

export function WelcomeScreen({ navigation }: Props) {
  const screenOpacity = useRef(new Animated.Value(0)).current;
  const containerScale = useRef(new Animated.Value(0.5)).current;
  const containerOpacity = useRef(new Animated.Value(0)).current;
  const imageY = useRef(new Animated.Value(20)).current;
  const textY = useRef(new Animated.Value(20)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Fade in the whole screen
    Animated.timing(screenOpacity, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    // Scale + fade in the container (delay 200ms)
    Animated.parallel([
      Animated.timing(containerScale, {
        toValue: 1,
        duration: 800,
        delay: 200,
        useNativeDriver: true,
      }),
      Animated.timing(containerOpacity, {
        toValue: 1,
        duration: 800,
        delay: 200,
        useNativeDriver: true,
      }),
    ]).start();

    // Image slides up (delay 500ms)
    Animated.timing(imageY, {
      toValue: 0,
      duration: 600,
      delay: 500,
      useNativeDriver: true,
    }).start();

    // Text slides up + fades in (delay 800ms)
    Animated.parallel([
      Animated.timing(textY, {
        toValue: 0,
        duration: 600,
        delay: 800,
        useNativeDriver: true,
      }),
      Animated.timing(textOpacity, {
        toValue: 1,
        duration: 600,
        delay: 800,
        useNativeDriver: true,
      }),
    ]).start();

    // Auto-navigate after 3 seconds, fade out first
    const timer = setTimeout(() => {
      Animated.timing(screenOpacity, {
        toValue: 0,
        duration: 500,
        useNativeDriver: true,
      }).start(() => {
        navigation.replace('Main');
      });
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <Animated.View style={[styles.screen, { opacity: screenOpacity }]}>
      <StarryBackground />
      <Animated.View
        style={[
          styles.content,
          {
            opacity: containerOpacity,
            transform: [{ scale: containerScale }],
          },
        ]}
      >
        <Animated.Image
          source={{
            uri: 'https://images.unsplash.com/photo-1630512874316-88dcd1925237?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=400',
          }}
          style={[
            styles.image,
            { transform: [{ translateY: imageY }] },
          ]}
        />
        <Animated.View
          style={[
            styles.textContainer,
            {
              opacity: textOpacity,
              transform: [{ translateY: textY }],
            },
          ]}
        >
          <Text style={styles.welcomeText}>Welcome to</Text>
          <Text style={styles.brandText}>Sunshine Sleep Mask</Text>
        </Animated.View>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: colors.black,
    alignItems: 'center',
    justifyContent: 'center',
  },
  content: {
    alignItems: 'center',
    gap: spacing['3xl'],
    zIndex: 10,
  },
  image: {
    width: 256,
    height: 256,
    borderRadius: 128,
  },
  textContainer: {
    alignItems: 'center',
  },
  welcomeText: {
    color: colors.white,
    fontSize: fontSizes['4xl'],
    fontWeight: '300',
    letterSpacing: 1,
    marginBottom: spacing.xs,
  },
  brandText: {
    color: colors.teal400,
    fontSize: fontSizes['4xl'],
    fontWeight: '600',
  },
});

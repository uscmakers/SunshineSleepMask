import React, { useState } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Image,
} from 'react-native';
import Svg, { Path, Rect, Circle, Polyline, Line } from 'react-native-svg';
import { colors, fontSizes, spacing, borderRadius } from '../theme';

// ── Inline icon components (swap for react-native-vector-icons if preferred) ──

function BluetoothIcon({ size = 24, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polyline points="6.5 6.5 17.5 17.5 12 23 12 1 17.5 6.5 6.5 17.5" />
    </Svg>
  );
}

function BatteryIcon({ size = 24, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Rect x="1" y="6" width="18" height="12" rx="2" ry="2" />
      <Line x1="23" y1="13" x2="23" y2="11" />
    </Svg>
  );
}

function MoonIcon({ size = 24, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </Svg>
  );
}

function AlarmIcon({ size = 24, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Circle cx="12" cy="13" r="8" />
      <Path d="M12 9v4l2 2" />
      <Path d="M5 3L2 6" />
      <Path d="M22 6l-3-3" />
    </Svg>
  );
}

function MusicIcon({ size = 24, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Path d="M9 18V5l12-2v13" />
      <Circle cx="6" cy="18" r="3" />
      <Circle cx="18" cy="16" r="3" />
    </Svg>
  );
}

function ActivityIcon({ size = 24, color = colors.teal400 }) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
      <Polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </Svg>
  );
}

// ── Component ──────────────────────────────────────────────────────────────────

export function HomePage() {
  const [isConnected, setIsConnected] = useState(true);

  return (
    <ScrollView
      style={styles.scroll}
      contentContainerStyle={styles.container}
      showsVerticalScrollIndicator={false}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Sunshine Sleep Mask</Text>
        <Text style={styles.headerSubtitle}>Your personal sleep companion</Text>
      </View>

      {/* Connection Status & Battery */}
      <View style={styles.card}>
        <View style={styles.row}>
          <View style={styles.row}>
            <View style={[styles.iconBadge, isConnected && styles.iconBadgeTeal]}>
              <BluetoothIcon size={24} color={isConnected ? colors.teal400 : colors.neutral600} />
            </View>
            <View style={styles.ml3}>
              <Text style={styles.cardTitle}>{isConnected ? 'Connected' : 'Disconnected'}</Text>
              <Text style={styles.cardSubtitle}>
                {isConnected ? 'Sunshine Mask #1234' : 'Tap to connect'}
              </Text>
            </View>
          </View>
          <View style={styles.batteryBadge}>
            <BatteryIcon size={20} />
            <Text style={styles.batteryText}>85%</Text>
          </View>
        </View>
        {!isConnected && (
          <TouchableOpacity
            style={styles.connectButton}
            onPress={() => setIsConnected(true)}
          >
            <Text style={styles.connectButtonText}>Connect Device</Text>
          </TouchableOpacity>
        )}
      </View>

      {/* Sleep Mask Image */}
      <View style={styles.card}>
        <Image
          source={{
            uri: 'https://images.unsplash.com/photo-1630512874316-88dcd1925237?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600',
          }}
          style={styles.maskImage}
          resizeMode="cover"
        />
        <View style={styles.maskLabel}>
          <Text style={styles.cardSubtitle}>Model</Text>
          <Text style={styles.cardTitle}>Sunshine Sleep Mask Pro</Text>
        </View>
      </View>

      {/* Current Settings */}
      <View style={styles.card}>
        <View style={[styles.row, styles.mb4]}>
          <ActivityIcon size={20} />
          <Text style={[styles.cardTitle, styles.ml2]}>Current Settings</Text>
        </View>

        {[
          {
            Icon: AlarmIcon,
            title: 'Next Alarm',
            subtitle: '7:00 AM • Gentle Sunrise (20 min)',
          },
          {
            Icon: MusicIcon,
            title: 'Active Sound',
            subtitle: 'Ocean Waves • 30 min timer',
          },
          {
            Icon: MoonIcon,
            title: 'Night Mode',
            subtitle: 'Enabled • Low light brightness',
          },
        ].map(({ Icon, title, subtitle }) => (
          <View key={title} style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <Icon size={20} />
            </View>
            <View style={styles.flex1}>
              <Text style={styles.settingTitle}>{title}</Text>
              <Text style={styles.settingSubtitle}>{subtitle}</Text>
            </View>
          </View>
        ))}
      </View>

      {/* Last Night's Sleep */}
      <View style={styles.card}>
        <View style={[styles.row, styles.mb5]}>
          <MoonIcon size={24} />
          <Text style={[styles.sleepSectionTitle, styles.ml2]}>Last Night's Sleep</Text>
        </View>

        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>Total Duration</Text>
            <Text style={styles.statValueLg}>7h 42m</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>Sleep Quality</Text>
            <Text style={[styles.statValueLg, { color: colors.teal400 }]}>92%</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>Deep Sleep</Text>
            <Text style={styles.statValueMd}>2h 15m</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>REM Sleep</Text>
            <Text style={styles.statValueMd}>1h 48m</Text>
          </View>
        </View>

        <View style={styles.insightBox}>
          <Text style={styles.insightLabel}>💡 Insight</Text>
          <Text style={styles.insightText}>
            Excellent sleep quality! Your deep sleep was 18% above average.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  scroll: { flex: 1 },
  container: {
    padding: spacing.xl,
    paddingBottom: spacing['4xl'],
    gap: spacing.xl,
  },

  // Header
  header: { alignItems: 'center', paddingTop: spacing.base, paddingBottom: spacing.sm },
  headerTitle: { fontSize: fontSizes['3xl'], color: colors.white, marginBottom: spacing.xs, fontWeight: '300' },
  headerSubtitle: { color: colors.neutral400, fontSize: fontSizes.base },

  // Card base
  card: {
    backgroundColor: colors.neutral900,
    borderWidth: 1,
    borderColor: colors.neutral800,
    borderRadius: borderRadius.lg,
    padding: spacing.lg,
  },

  // Row helpers
  row: { flexDirection: 'row', alignItems: 'center' },
  ml2: { marginLeft: spacing.sm },
  ml3: { marginLeft: spacing.md },
  mb4: { marginBottom: spacing.base },
  mb5: { marginBottom: spacing.lg },
  flex1: { flex: 1 },

  // Connection card
  iconBadge: {
    padding: spacing.md,
    borderRadius: borderRadius.full,
    backgroundColor: colors.neutral800,
  },
  iconBadgeTeal: { backgroundColor: colors.teal500_10 },
  cardTitle: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base },
  cardSubtitle: { color: colors.neutral400, fontSize: fontSizes.sm, marginTop: 2 },
  batteryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    backgroundColor: colors.neutral800,
    paddingHorizontal: spacing.base,
    paddingVertical: spacing.sm,
    borderRadius: borderRadius.full,
  },
  batteryText: { color: colors.white, fontSize: fontSizes.lg, fontWeight: '500' },
  connectButton: {
    marginTop: spacing.base,
    backgroundColor: colors.teal500,
    borderRadius: borderRadius.md,
    paddingVertical: spacing.sm,
    alignItems: 'center',
  },
  connectButtonText: { color: colors.white, fontWeight: '600' },

  // Mask image
  maskImage: { width: '100%', height: 200, borderRadius: borderRadius.md },
  maskLabel: { marginTop: spacing.base },

  // Settings rows
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.neutral800,
    borderWidth: 1,
    borderColor: colors.neutral700,
    borderRadius: borderRadius.md,
    padding: spacing.md,
    marginBottom: spacing.sm,
    gap: spacing.md,
  },
  settingIconWrap: {
    padding: spacing.sm,
    borderRadius: borderRadius.md,
    backgroundColor: colors.teal500_10,
  },
  settingTitle: { color: colors.white, fontWeight: '600', fontSize: fontSizes.base },
  settingSubtitle: { color: colors.neutral400, fontSize: fontSizes.sm, marginTop: 2 },

  // Sleep stats
  sleepSectionTitle: { color: colors.white, fontWeight: '600', fontSize: fontSizes.lg },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.base,
    marginBottom: spacing.lg,
  },
  statCard: {
    flex: 1,
    minWidth: '45%',
    backgroundColor: colors.neutral800,
    borderWidth: 1,
    borderColor: colors.neutral700,
    borderRadius: borderRadius.md,
    padding: spacing.base,
  },
  statLabel: { color: colors.neutral400, fontSize: fontSizes.sm, marginBottom: spacing.xs },
  statValueLg: { color: colors.white, fontSize: fontSizes['3xl'], fontWeight: '300' },
  statValueMd: { color: colors.white, fontSize: fontSizes['2xl'], fontWeight: '300' },

  // Insight
  insightBox: {
    backgroundColor: colors.teal500_10,
    borderWidth: 1,
    borderColor: colors.teal500_20,
    borderRadius: borderRadius.md,
    padding: spacing.base,
  },
  insightLabel: { color: colors.teal400, fontWeight: '600', marginBottom: spacing.xs, fontSize: fontSizes.sm },
  insightText: { color: colors.neutral300, fontSize: fontSizes.sm },
});
